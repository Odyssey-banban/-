// src/components/QuickNavCards.jsx
'use client';

import { useTranslations } from 'next-intl';
import { Link } from '@/lib/i18n';

export default function QuickNavCards() {
  const t = useTranslations('home.quickNav');
  
  return (
    <section className="quick-nav-section py-16">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* 作品集卡片 */}
          <Link href="/portfolio" className="nav-card bg-gradient-to-br from-[#2A5C8A]/10 to-[#2A5C8A]/30 p-6 rounded-lg border border-[#2A5C8A]/50 hover:border-[#4BCF93] transition-all duration-300 hover:shadow-lg hover:shadow-[#4BCF93]/20 group">
            <div className="h-40 flex items-center justify-center mb-4">
              <div className="w-20 h-20 bg-[#2A5C8A] rounded-full flex items-center justify-center group-hover:bg-[#4BCF93] transition-colors duration-300">
                <span className="text-3xl">📊</span>
              </div>
            </div>
            <h3 className="text-xl font-bold mb-2 text-center group-hover:text-[#4BCF93] transition-colors duration-300">{t('portfolio')}</h3>
          </Link>
          
          {/* 热点分析卡片 */}
          <Link href="/analysis" className="nav-card bg-gradient-to-br from-[#2A5C8A]/10 to-[#2A5C8A]/30 p-6 rounded-lg border border-[#2A5C8A]/50 hover:border-[#4BCF93] transition-all duration-300 hover:shadow-lg hover:shadow-[#4BCF93]/20 group">
            <div className="h-40 flex items-center justify-center mb-4">
              <div className="w-20 h-20 bg-[#2A5C8A] rounded-full flex items-center justify-center group-hover:bg-[#4BCF93] transition-colors duration-300">
                <span className="text-3xl">📈</span>
              </div>
            </div>
            <h3 className="text-xl font-bold mb-2 text-center group-hover:text-[#4BCF93] transition-colors duration-300">{t('analysis')}</h3>
          </Link>
          
          {/* 科普专栏卡片 */}
          <Link href="/education" className="nav-card bg-gradient-to-br from-[#2A5C8A]/10 to-[#2A5C8A]/30 p-6 rounded-lg border border-[#2A5C8A]/50 hover:border-[#4BCF93] transition-all duration-300 hover:shadow-lg hover:shadow-[#4BCF93]/20 group">
            <div className="h-40 flex items-center justify-center mb-4">
              <div className="w-20 h-20 bg-[#2A5C8A] rounded-full flex items-center justify-center group-hover:bg-[#4BCF93] transition-colors duration-300">
                <span className="text-3xl">📚</span>
              </div>
            </div>
            <h3 className="text-xl font-bold mb-2 text-center group-hover:text-[#4BCF93] transition-colors duration-300">{t('education')}</h3>
          </Link>
          
          {/* 关于我卡片 */}
          <Link href="/about" className="nav-card bg-gradient-to-br from-[#2A5C8A]/10 to-[#2A5C8A]/30 p-6 rounded-lg border border-[#2A5C8A]/50 hover:border-[#4BCF93] transition-all duration-300 hover:shadow-lg hover:shadow-[#4BCF93]/20 group">
            <div className="h-40 flex items-center justify-center mb-4">
              <div className="w-20 h-20 bg-[#2A5C8A] rounded-full flex items-center justify-center group-hover:bg-[#4BCF93] transition-colors duration-300">
                <span className="text-3xl">👤</span>
              </div>
            </div>
            <h3 className="text-xl font-bold mb-2 text-center group-hover:text-[#4BCF93] transition-colors duration-300">{t('about')}</h3>
          </Link>
        </div>
      </div>
    </section>
  );
}
