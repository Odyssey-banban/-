// src/components/FeaturedContent.jsx
'use client';

import { useTranslations } from 'next-intl';
import { useState } from 'react';
import { Link } from '@/lib/i18n';

export default function FeaturedContent() {
  const t = useTranslations('home.featuredContent');
  const [activeSlide, setActiveSlide] = useState(0);
  
  // 模拟精选内容数据
  const featuredItems = [
    {
      id: 1,
      title: '美联储降息对比特币市场的影响分析',
      excerpt: '本文深入分析美联储降息25个基点对加密货币市场的短期和长期影响，并提供相应的投资策略建议。',
      image: '/images/fed-btc-analysis.jpg',
      category: 'analysis',
      date: '2025-04-01'
    },
    {
      id: 2,
      title: 'Layer 2扩容方案对比：哪个更适合DeFi应用？',
      excerpt: '本文对比Optimism、Arbitrum、zkSync等主流Layer 2扩容方案的技术特点、性能表现和生态发展，帮助开发者选择最适合的平台。',
      image: '/images/layer2-comparison.jpg',
      category: 'analysis',
      date: '2025-03-28'
    },
    {
      id: 3,
      title: '加密货币监管趋势：全球视角',
      excerpt: '从美国SEC到欧盟MiCA，本文梳理全球主要经济体的加密货币监管动向，分析未来监管格局的演变趋势。',
      image: '/images/crypto-regulation.jpg',
      category: 'analysis',
      date: '2025-03-25'
    },
    {
      id: 4,
      title: '加密货币的哲学思考：数字主权与金融自由',
      excerpt: '本文从哲学角度探讨加密货币带来的数字主权革命，以及它如何重塑我们对金融自由的理解。',
      image: '/images/crypto-philosophy.jpg',
      category: 'thoughts',
      date: '2025-03-20'
    }
  ];
  
  const nextSlide = () => {
    setActiveSlide((prev) => (prev === featuredItems.length - 1 ? 0 : prev + 1));
  };
  
  const prevSlide = () => {
    setActiveSlide((prev) => (prev === 0 ? featuredItems.length - 1 : prev - 1));
  };
  
  return (
    <section className="featured-content-section py-16">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl font-bold mb-8">
          {t('title')}
        </h2>
        
        <div className="relative">
          {/* 轮播控制按钮 */}
          <button 
            onClick={prevSlide}
            className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-[#2A5C8A] hover:bg-[#4BCF93] text-white p-2 rounded-full"
            aria-label="Previous slide"
          >
            ←
          </button>
          
          <button 
            onClick={nextSlide}
            className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-[#2A5C8A] hover:bg-[#4BCF93] text-white p-2 rounded-full"
            aria-label="Next slide"
          >
            →
          </button>
          
          {/* 轮播内容 */}
          <div className="carousel-container overflow-hidden">
            <div 
              className="carousel-track flex transition-transform duration-500 ease-in-out"
              style={{ transform: `translateX(-${activeSlide * 100}%)` }}
            >
              {featuredItems.map((item) => (
                <div key={item.id} className="carousel-slide w-full flex-shrink-0 px-4">
                  <div className="bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300">
                    <div className="aspect-video bg-gray-200 dark:bg-gray-700 relative">
                      {/* 实际项目中应该使用真实图片 */}
                      <div className="absolute inset-0 flex items-center justify-center text-gray-500 dark:text-gray-400">
                        [图片占位符: {item.title}]
                      </div>
                    </div>
                    
                    <div className="p-6">
                      <div className="flex items-center mb-4">
                        <span className="text-xs font-semibold px-2 py-1 bg-[#2A5C8A]/10 text-[#2A5C8A] dark:text-[#4BCF93] rounded">
                          {item.category === 'analysis' ? t('latestAnalysis') : t('deepThoughts')}
                        </span>
                        <span className="text-xs text-gray-500 dark:text-gray-400 ml-2">
                          {item.date}
                        </span>
                      </div>
                      
                      <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                      <p className="text-gray-600 dark:text-gray-300 mb-4">{item.excerpt}</p>
                      
                      <Link 
                        href={`/${item.category}/${item.id}`}
                        className="inline-block bg-[#2A5C8A] hover:bg-[#4BCF93] text-white font-semibold py-2 px-4 rounded transition-colors duration-300"
                      >
                        阅读更多
                      </Link>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* 轮播指示器 */}
          <div className="carousel-indicators flex justify-center mt-4">
            {featuredItems.map((_, index) => (
              <button
                key={index}
                onClick={() => setActiveSlide(index)}
                className={`w-3 h-3 rounded-full mx-1 ${
                  activeSlide === index ? 'bg-[#4BCF93]' : 'bg-gray-300 dark:bg-gray-600'
                }`}
                aria-label={`Go to slide ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
