// src/components/ContactSection.jsx
'use client';

import { useTranslations } from 'next-intl';

export default function ContactSection() {
  const t = useTranslations('about.contact');
  
  return (
    <section className="contact-section py-16 bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl font-bold mb-8 text-center">联系方式</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* 加密原生方式 */}
          <div className="contact-card bg-white dark:bg-gray-800 rounded-lg p-6 shadow-md">
            <h3 className="text-xl font-bold mb-4 text-[#2A5C8A] dark:text-[#4BCF93]">{t('crypto')}</h3>
            
            <div className="space-y-6">
              <div>
                <h4 className="font-semibold mb-2">ENS域名</h4>
                <div className="flex items-center">
                  <span className="text-gray-700 dark:text-gray-300 font-mono bg-gray-100 dark:bg-gray-700 px-3 py-2 rounded">odyssey.eth</span>
                  <button className="ml-2 text-[#2A5C8A] hover:text-[#4BCF93]" aria-label="复制ENS域名">
                    📋
                  </button>
                </div>
              </div>
              
              <div>
                <h4 className="font-semibold mb-2">闪电网络支付码</h4>
                <div className="bg-white p-4 inline-block rounded">
                  {/* 实际项目中应该使用真实的闪电网络支付码图片 */}
                  <div className="w-40 h-40 bg-gray-200 flex items-center justify-center text-gray-500">
                    [闪电网络支付码]
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* 传统方式 */}
          <div className="contact-card bg-white dark:bg-gray-800 rounded-lg p-6 shadow-md">
            <h3 className="text-xl font-bold mb-4 text-[#2A5C8A] dark:text-[#4BCF93]">{t('traditional')}</h3>
            
            <div className="space-y-6">
              <div>
                <h4 className="font-semibold mb-2">加密邮箱</h4>
                <div className="flex items-center">
                  <span className="text-gray-700 dark:text-gray-300 font-mono bg-gray-100 dark:bg-gray-700 px-3 py-2 rounded">contact@odyssey-crypto.com</span>
                  <button className="ml-2 text-[#2A5C8A] hover:text-[#4BCF93]" aria-label="复制邮箱地址">
                    📋
                  </button>
                </div>
              </div>
              
              <div>
                <h4 className="font-semibold mb-2">社媒矩阵</h4>
                <div className="flex flex-wrap gap-4">
                  <a 
                    href="https://twitter.com/odyssey" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center bg-[#1DA1F2] text-white px-4 py-2 rounded hover:bg-opacity-90 transition-colors"
                  >
                    <span className="mr-2">🐦</span>
                    Twitter
                  </a>
                  
                  <a 
                    href="https://mirror.xyz/odyssey" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center bg-[#007AFF] text-white px-4 py-2 rounded hover:bg-opacity-90 transition-colors"
                  >
                    <span className="mr-2">📝</span>
                    Mirror.xyz
                  </a>
                  
                  <a 
                    href="https://github.com/odyssey" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center bg-[#333] text-white px-4 py-2 rounded hover:bg-opacity-90 transition-colors"
                  >
                    <span className="mr-2">💻</span>
                    GitHub
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
