// src/components/HeroSection.jsx
'use client';

import { useTranslations } from 'next-intl';

export default function HeroSection() {
  const t = useTranslations('home.hero');
  
  return (
    <section className="hero-section relative h-screen flex items-center">
      {/* 动态背景 - 抽象加密元素 */}
      <div className="absolute inset-0 overflow-hidden z-0">
        <div className="crypto-elements-animation">
          {/* 这里将通过CSS实现区块链线条和数字货币3D模型动画效果 */}
          <div className="blockchain-lines"></div>
          <div className="crypto-particles"></div>
        </div>
      </div>
      
      {/* 内容区域 */}
      <div className="container mx-auto px-4 z-10 text-center">
        <h1 className="text-4xl md:text-6xl font-bold mb-6 text-white glitch-text">
          Odyssey
        </h1>
        <p className="text-xl md:text-2xl mb-8 text-gray-200">
          {t('slogan')}
        </p>
        <button className="bg-[#4BCF93] hover:bg-[#3db980] text-white font-bold py-3 px-8 rounded-lg transition-all duration-300 transform hover:scale-105 neon-glow">
          {t('cta')}
        </button>
      </div>
    </section>
  );
}
