// src/components/Header.jsx
'use client';

import { useTranslations } from 'next-intl';
import Navigation from './Navigation';
import LanguageSwitcher from './LanguageSwitcher';
import ThemeSwitcher from './ThemeSwitcher';
import MobileMenu from './MobileMenu';
import { Link } from '@/lib/i18n';

export default function Header() {
  const t = useTranslations('common');
  
  return (
    <header className="site-header bg-white dark:bg-gray-800 shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="logo">
          <Link href="/" className="text-2xl font-bold text-[#2A5C8A] dark:text-[#4BCF93]">
            Odyssey
          </Link>
        </div>
        
        <div className="hidden md:flex items-center">
          <Navigation />
          
          <div className="flex items-center ml-4 space-x-4">
            <LanguageSwitcher />
            <ThemeSwitcher />
          </div>
        </div>
        
        <MobileMenu />
      </div>
    </header>
  );
}
