// src/components/EducationLevelFilter.jsx
'use client';

import { useTranslations } from 'next-intl';
import { useState } from 'react';

export default function EducationLevelFilter({ onFilterChange }) {
  const t = useTranslations('education.levels');
  const [activeLevel, setActiveLevel] = useState('all');
  
  const levels = [
    { id: 'all', label: '全部' },
    { id: 'beginner', label: t('beginner') },
    { id: 'intermediate', label: t('intermediate') },
    { id: 'advanced', label: t('advanced') }
  ];
  
  const handleLevelChange = (level) => {
    setActiveLevel(level);
    if (onFilterChange) {
      onFilterChange(level);
    }
  };
  
  return (
    <div className="education-level-filter mb-8">
      <div className="flex flex-wrap gap-2">
        {levels.map((level) => (
          <button
            key={level.id}
            onClick={() => handleLevelChange(level.id)}
            className={`px-4 py-2 rounded-full transition-colors duration-300 ${
              activeLevel === level.id
                ? 'bg-[#2A5C8A] text-white'
                : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-600'
            }`}
          >
            {level.label}
          </button>
        ))}
      </div>
    </div>
  );
}
