// src/components/AnalysisCard.jsx
'use client';

import { useTranslations } from 'next-intl';
import { Link } from '@/lib/i18n';

export default function AnalysisCard({ analysis }) {
  const t = useTranslations('analysis.structure');
  
  // 使用默认分析数据，实际应从props接收
  const defaultAnalysis = {
    id: 1,
    title: '美联储降息对BTC波动率的影响',
    slug: 'fed-rate-cut-btc-volatility',
    tags: ['regulation'],
    date: '2025-04-01',
    event: '美联储宣布降息25个基点，为2023年以来首次降息。',
    data: '降息后24小时内，BTC波动率上升42%，价格上涨8.5%。',
    impact: '短期：市场情绪转向乐观，资金流入加密市场。长期：可能引发新一轮牛市周期。',
    action: '建议采取定投策略，逐步增加仓位，同时设置止损保护既有收益。'
  };
  
  const analysisData = analysis || defaultAnalysis;
  
  // 使用analysisData替代所有analysis引用
  
  return (
    <div className="analysis-card bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-all duration-300">
      <div className="p-6">
        <div className="flex items-center mb-3">
          {analysisData.tags.map((tag) => (
            <span key={tag} className="text-xs font-semibold px-2 py-1 bg-[#2A5C8A]/10 text-[#2A5C8A] dark:text-[#4BCF93] rounded mr-2">
              #{tag}
            </span>
          ))}
          <span className="text-xs text-gray-500 dark:text-gray-400 ml-auto">
            {analysisData.date}
          </span>
        </div>
        
        <h3 className="text-xl font-bold mb-4">{analysisData.title}</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <div className="analysis-section">
            <h4 className="text-md font-semibold text-[#2A5C8A] dark:text-[#4BCF93] mb-2">{t('event')}</h4>
            <p className="text-gray-700 dark:text-gray-300">{analysisData.event}</p>
          </div>
          
          <div className="analysis-section">
            <h4 className="text-md font-semibold text-[#2A5C8A] dark:text-[#4BCF93] mb-2">{t('data')}</h4>
            <p className="text-gray-700 dark:text-gray-300">{analysisData.data}</p>
          </div>
          
          <div className="analysis-section">
            <h4 className="text-md font-semibold text-[#2A5C8A] dark:text-[#4BCF93] mb-2">{t('impact')}</h4>
            <p className="text-gray-700 dark:text-gray-300">{analysisData.impact}</p>
          </div>
          
          <div className="analysis-section">
            <h4 className="text-md font-semibold text-[#2A5C8A] dark:text-[#4BCF93] mb-2">{t('action')}</h4>
            <p className="text-gray-700 dark:text-gray-300">{analysisData.action}</p>
          </div>
        </div>
        
        <div className="flex justify-end">
          <Link 
            href={`/analysis/${analysisData.slug}`}
            className="inline-block bg-[#2A5C8A] hover:bg-[#4BCF93] text-white font-semibold py-2 px-4 rounded transition-colors duration-300"
          >
            查看完整分析
          </Link>
        </div>
      </div>
    </div>
  );
}
