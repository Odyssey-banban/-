// src/components/EducationCard.jsx
'use client';

import { useTranslations } from 'next-intl';
import { Link } from '@/lib/i18n';

export default function EducationCard({ content }) {
  const t = useTranslations('education.levels');
  
  // 使用默认教育内容数据，实际应从props接收
  const defaultContent = {
    id: 1,
    title: '钱包创建全流程指南',
    slug: 'wallet-creation-guide',
    level: 'beginner',
    thumbnail: '/images/wallet-guide.jpg',
    excerpt: '从零开始学习如何创建和安全管理加密货币钱包，包括助记词备份、私钥保管和常见安全陷阱。',
    date: '2025-03-15'
  };
  
  const content = content || defaultContent;
  
  // 根据内容级别设置不同的样式
  const getLevelStyle = (level) => {
    switch(level) {
      case 'beginner':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'intermediate':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      case 'advanced':
        return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
    }
  };
  
  return (
    <div className="education-card bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-all duration-300">
      <div className="aspect-video bg-gray-200 dark:bg-gray-700 relative">
        {/* 实际项目中应该使用真实图片 */}
        <div className="absolute inset-0 flex items-center justify-center text-gray-500 dark:text-gray-400">
          [图片占位符: {content.title}]
        </div>
      </div>
      
      <div className="p-6">
        <div className="flex items-center mb-3">
          <span className={`text-xs font-semibold px-2 py-1 rounded ${getLevelStyle(content.level)}`}>
            {t(content.level)}
          </span>
          <span className="text-xs text-gray-500 dark:text-gray-400 ml-auto">
            {content.date}
          </span>
        </div>
        
        <h3 className="text-xl font-bold mb-3">{content.title}</h3>
        <p className="text-gray-600 dark:text-gray-300 mb-4">{content.excerpt}</p>
        
        <Link 
          href={`/education/${content.slug}`}
          className="inline-block bg-[#2A5C8A] hover:bg-[#4BCF93] text-white font-semibold py-2 px-4 rounded transition-colors duration-300"
        >
          开始学习
        </Link>
      </div>
    </div>
  );
}
