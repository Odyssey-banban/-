// src/components/TrustBadges.jsx
'use client';

import { useTranslations } from 'next-intl';

export default function TrustBadges() {
  const t = useTranslations('portfolio.trustBadges');
  
  // 模拟合作机构数据
  const partners = [
    { id: 1, name: 'Binance Research', logo: '/images/binance-research.png' },
    { id: 2, name: 'Delphi Digital', logo: '/images/delphi-digital.png' },
    { id: 3, name: 'Messari', logo: '/images/messari.png' },
    { id: 4, name: 'The Block', logo: '/images/the-block.png' },
    { id: 5, name: 'CoinDesk', logo: '/images/coindesk.png' }
  ];
  
  // 模拟读者评价数据
  const testimonials = [
    { id: 1, text: '"Odyssey的分析深入浅出，帮助我在市场波动中保持冷静。"', author: '资深投资者 @Crypto_Whale' },
    { id: 2, text: '"最喜欢Odyssey的技术解析，没有之一。专业且易懂。"', author: '区块链开发者 @Chain_Builder' },
    { id: 3, text: '"Odyssey的市场预测准确度令人惊叹，已经成为我投资决策的重要参考。"', author: '基金经理 @Fund_Manager' }
  ];
  
  return (
    <section className="trust-badges-section py-16 bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <div className="partners mb-16">
          <h3 className="text-2xl font-bold mb-8 text-center">{t('partners')}</h3>
          
          <div className="flex flex-wrap justify-center items-center gap-8">
            {partners.map((partner) => (
              <div key={partner.id} className="partner-logo grayscale hover:grayscale-0 transition-all duration-300">
                {/* 实际项目中应该使用真实Logo */}
                <div className="w-32 h-16 bg-white dark:bg-gray-800 rounded flex items-center justify-center shadow-sm">
                  <span className="text-gray-500 dark:text-gray-400 text-sm font-medium">{partner.name}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="testimonials">
          <h3 className="text-2xl font-bold mb-8 text-center">{t('testimonials')}</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((testimonial) => (
              <div key={testimonial.id} className="testimonial-card bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
                <div className="quote-mark text-4xl text-[#2A5C8A] dark:text-[#4BCF93] mb-2">"</div>
                <p className="text-gray-700 dark:text-gray-300 mb-4 italic">{testimonial.text}</p>
                <p className="text-sm font-semibold text-gray-600 dark:text-gray-400">{testimonial.author}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
