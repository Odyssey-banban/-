// src/components/Footer.jsx
'use client';

import { useTranslations } from 'next-intl';
import { Link } from '@/lib/i18n';

export default function Footer() {
  const t = useTranslations('common.footer');
  
  return (
    <footer className="site-footer bg-gray-900 text-white py-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">Odyssey</h3>
            <p className="text-gray-400">{t('copyright')}</p>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-3">Links</h4>
            <ul className="space-y-2">
              <li><Link href="/privacy">{t('privacy')}</Link></li>
              <li><Link href="/terms">{t('terms')}</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-3">{t('contact')}</h4>
            <ul className="space-y-2">
              <li>Email: contact@odyssey-crypto.com</li>
              <li>ENS: odyssey.eth</li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-3">Social</h4>
            <div className="flex space-x-4">
              <a href="https://twitter.com/odyssey" target="_blank" rel="noopener noreferrer">
                Twitter
              </a>
              <a href="https://mirror.xyz/odyssey" target="_blank" rel="noopener noreferrer">
                Mirror.xyz
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
