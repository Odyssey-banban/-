// src/components/OpinionPoll.jsx
'use client';

import { useState } from 'react';
import { useTranslations } from 'next-intl';

export default function OpinionPoll() {
  const t = useTranslations('analysis.interactive');
  const [selectedOption, setSelectedOption] = useState(null);
  const [hasVoted, setHasVoted] = useState(false);
  
  // 模拟投票数据
  const [votes, setVotes] = useState({
    a: 42,
    b: 35,
    c: 23
  });
  
  const handleVote = () => {
    if (selectedOption && !hasVoted) {
      setVotes(prev => ({
        ...prev,
        [selectedOption]: prev[selectedOption] + 1
      }));
      setHasVoted(true);
    }
  };
  
  // 计算总票数和百分比
  const totalVotes = Object.values(votes).reduce((sum, count) => sum + count, 0);
  const getPercentage = (count) => Math.round((count / totalVotes) * 100);
  
  return (
    <div className="opinion-poll bg-white dark:bg-gray-800 rounded-lg p-6 shadow-md">
      <h3 className="text-xl font-bold mb-4">{t('opinion')}</h3>
      <p className="text-gray-700 dark:text-gray-300 mb-6">你看好BTC本轮反弹高度？</p>
      
      <div className="options space-y-4 mb-6">
        {!hasVoted ? (
          <>
            <label className="flex items-center space-x-2 cursor-pointer">
              <input
                type="radio"
                name="opinion"
                value="a"
                checked={selectedOption === 'a'}
                onChange={() => setSelectedOption('a')}
                className="form-radio text-[#2A5C8A]"
              />
              <span>A. 10万刀</span>
            </label>
            
            <label className="flex items-center space-x-2 cursor-pointer">
              <input
                type="radio"
                name="opinion"
                value="b"
                checked={selectedOption === 'b'}
                onChange={() => setSelectedOption('b')}
                className="form-radio text-[#2A5C8A]"
              />
              <span>B. 8万刀</span>
            </label>
            
            <label className="flex items-center space-x-2 cursor-pointer">
              <input
                type="radio"
                name="opinion"
                value="c"
                checked={selectedOption === 'c'}
                onChange={() => setSelectedOption('c')}
                className="form-radio text-[#2A5C8A]"
              />
              <span>C. 崩盘</span>
            </label>
          </>
        ) : (
          <>
            <div className="result-bar mb-3">
              <div className="flex justify-between mb-1">
                <span>A. 10万刀</span>
                <span>{getPercentage(votes.a)}%</span>
              </div>
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                <div 
                  className="bg-[#2A5C8A] h-2.5 rounded-full" 
                  style={{ width: `${getPercentage(votes.a)}%` }}
                ></div>
              </div>
            </div>
            
            <div className="result-bar mb-3">
              <div className="flex justify-between mb-1">
                <span>B. 8万刀</span>
                <span>{getPercentage(votes.b)}%</span>
              </div>
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                <div 
                  className="bg-[#2A5C8A] h-2.5 rounded-full" 
                  style={{ width: `${getPercentage(votes.b)}%` }}
                ></div>
              </div>
            </div>
            
            <div className="result-bar mb-3">
              <div className="flex justify-between mb-1">
                <span>C. 崩盘</span>
                <span>{getPercentage(votes.c)}%</span>
              </div>
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                <div 
                  className="bg-[#2A5C8A] h-2.5 rounded-full" 
                  style={{ width: `${getPercentage(votes.c)}%` }}
                ></div>
              </div>
            </div>
            
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-4">
              总票数: {totalVotes}
            </p>
          </>
        )}
      </div>
      
      {!hasVoted && (
        <button
          onClick={handleVote}
          disabled={!selectedOption}
          className={`w-full py-2 px-4 rounded font-semibold ${
            selectedOption
              ? 'bg-[#2A5C8A] hover:bg-[#4BCF93] text-white transition-colors duration-300'
              : 'bg-gray-300 dark:bg-gray-700 text-gray-500 dark:text-gray-400 cursor-not-allowed'
          }`}
        >
          {t('vote')}
        </button>
      )}
    </div>
  );
}
