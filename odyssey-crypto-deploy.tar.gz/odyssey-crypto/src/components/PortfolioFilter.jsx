// src/components/PortfolioFilter.jsx
'use client';

import { useTranslations } from 'next-intl';
import { useState } from 'react';

export default function PortfolioFilter({ onFilterChange }) {
  const t = useTranslations('portfolio.categories');
  const [activeCategory, setActiveCategory] = useState('all');
  
  const categories = [
    { id: 'all', label: '全部' },
    { id: 'research', label: t('research') },
    { id: 'investment', label: t('investment') },
    { id: 'media', label: t('media') },
    { id: 'tools', label: t('tools') }
  ];
  
  const handleCategoryChange = (category) => {
    setActiveCategory(category);
    if (onFilterChange) {
      onFilterChange(category);
    }
  };
  
  return (
    <div className="portfolio-filter mb-8">
      <div className="flex flex-wrap gap-2">
        {categories.map((category) => (
          <button
            key={category.id}
            onClick={() => handleCategoryChange(category.id)}
            className={`px-4 py-2 rounded-full transition-colors duration-300 ${
              activeCategory === category.id
                ? 'bg-[#2A5C8A] text-white'
                : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-600'
            }`}
          >
            {category.label}
          </button>
        ))}
      </div>
    </div>
  );
}
