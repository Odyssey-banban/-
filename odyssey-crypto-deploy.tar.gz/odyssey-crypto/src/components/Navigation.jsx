'use client';

import { useTranslations } from 'next-intl';
import { Link } from '@/lib/i18n';

export default function Navigation() {
  const t = useTranslations('common.navigation');
  
  return (
    <nav className="main-navigation">
      <ul>
        <li>
          <Link href="/">{t('home')}</Link>
        </li>
        <li>
          <Link href="/portfolio">{t('portfolio')}</Link>
        </li>
        <li>
          <Link href="/analysis">{t('analysis')}</Link>
        </li>
        <li>
          <Link href="/education">{t('education')}</Link>
        </li>
        <li>
          <Link href="/about">{t('about')}</Link>
        </li>
      </ul>
    </nav>
  );
}
