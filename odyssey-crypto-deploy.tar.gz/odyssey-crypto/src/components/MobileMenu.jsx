// src/components/MobileMenu.jsx
'use client';

import { useState } from 'react';
import { useTranslations } from 'next-intl';
import Navigation from './Navigation';
import LanguageSwitcher from './LanguageSwitcher';
import ThemeSwitcher from './ThemeSwitcher';

export default function MobileMenu() {
  const [isOpen, setIsOpen] = useState(false);
  
  const toggleMenu = () => {
    setIsOpen(!isOpen);
    document.body.classList.toggle('mobile-menu-open');
  };
  
  return (
    <div className="md:hidden">
      <button 
        onClick={toggleMenu}
        className="mobile-menu-button p-2"
        aria-label={isOpen ? "关闭菜单" : "打开菜单"}
      >
        {isOpen ? (
          <span className="text-2xl">✕</span>
        ) : (
          <span className="text-2xl">☰</span>
        )}
      </button>
      
      {isOpen && (
        <div className="fixed inset-0 bg-white dark:bg-gray-900 z-50 p-4 flex flex-col">
          <div className="flex justify-end">
            <button 
              onClick={toggleMenu}
              className="p-2"
              aria-label="关闭菜单"
            >
              <span className="text-2xl">✕</span>
            </button>
          </div>
          
          <div className="flex-1 flex flex-col items-center justify-center space-y-8">
            <Navigation />
            
            <div className="flex items-center space-x-4">
              <LanguageSwitcher />
              <ThemeSwitcher />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
