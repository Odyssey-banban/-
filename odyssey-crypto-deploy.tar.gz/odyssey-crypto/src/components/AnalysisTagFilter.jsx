// src/components/AnalysisTagFilter.jsx
'use client';

import { useTranslations } from 'next-intl';
import { useState } from 'react';

export default function AnalysisTagFilter({ onFilterChange }) {
  const t = useTranslations('analysis.tags');
  const [activeTag, setActiveTag] = useState('all');
  
  const tags = [
    { id: 'all', label: t('all') },
    { id: 'regulation', label: t('regulation') },
    { id: 'technology', label: t('technology') },
    { id: 'exchange', label: t('exchange') }
  ];
  
  const handleTagChange = (tag) => {
    setActiveTag(tag);
    if (onFilterChange) {
      onFilterChange(tag);
    }
  };
  
  return (
    <div className="analysis-tag-filter mb-8">
      <div className="flex flex-wrap gap-2">
        {tags.map((tag) => (
          <button
            key={tag.id}
            onClick={() => handleTagChange(tag.id)}
            className={`px-4 py-2 rounded-full transition-colors duration-300 ${
              activeTag === tag.id
                ? 'bg-[#2A5C8A] text-white'
                : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-600'
            }`}
          >
            {tag.label}
          </button>
        ))}
      </div>
    </div>
  );
}
