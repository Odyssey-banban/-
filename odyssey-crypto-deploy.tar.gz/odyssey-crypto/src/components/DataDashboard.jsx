// src/components/DataDashboard.jsx
'use client';

import { useTranslations } from 'next-intl';
import { useState, useEffect } from 'react';

export default function DataDashboard() {
  const t = useTranslations('home.dataPanel');
  const [cryptoData, setCryptoData] = useState({
    btcPrice: '0',
    ethPrice: '0',
    fearGreedIndex: '0',
    tvl: '0'
  });
  
  // 模拟获取加密货币数据
  useEffect(() => {
    // 实际项目中，这里应该从API获取实时数据
    const mockData = {
      btcPrice: '$68,245',
      ethPrice: '$3,875',
      fearGreedIndex: '72 (贪婪)',
      tvl: '$48.2B'
    };
    
    setCryptoData(mockData);
    
    // 设置定时器，模拟数据更新
    const timer = setInterval(() => {
      const randomChange = () => (Math.random() > 0.5 ? 1 : -1) * Math.floor(Math.random() * 100);
      
      setCryptoData(prev => ({
        btcPrice: `$${(parseInt(prev.btcPrice.replace(/[$,]/g, '')) + randomChange()).toLocaleString()}`,
        ethPrice: `$${(parseInt(prev.ethPrice.replace(/[$,]/g, '')) + randomChange() / 10).toLocaleString()}`,
        fearGreedIndex: prev.fearGreedIndex,
        tvl: prev.tvl
      }));
    }, 5000);
    
    return () => clearInterval(timer);
  }, []);
  
  return (
    <section className="data-dashboard-section py-12 bg-gray-100 dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl font-bold mb-8 text-center">
          Crypto Market Dashboard
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* BTC价格卡片 */}
          <div className="data-card bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md border-l-4 border-[#F7931A] hover:shadow-lg transition-shadow duration-300">
            <h3 className="text-lg font-semibold text-gray-600 dark:text-gray-400 mb-2">{t('btcPrice')}</h3>
            <p className="text-3xl font-bold text-gray-900 dark:text-white">{cryptoData.btcPrice}</p>
          </div>
          
          {/* ETH价格卡片 */}
          <div className="data-card bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md border-l-4 border-[#627EEA] hover:shadow-lg transition-shadow duration-300">
            <h3 className="text-lg font-semibold text-gray-600 dark:text-gray-400 mb-2">{t('ethPrice')}</h3>
            <p className="text-3xl font-bold text-gray-900 dark:text-white">{cryptoData.ethPrice}</p>
          </div>
          
          {/* 恐惧贪婪指数卡片 */}
          <div className="data-card bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md border-l-4 border-[#FF9900] hover:shadow-lg transition-shadow duration-300">
            <h3 className="text-lg font-semibold text-gray-600 dark:text-gray-400 mb-2">{t('fearGreedIndex')}</h3>
            <p className="text-3xl font-bold text-gray-900 dark:text-white">{cryptoData.fearGreedIndex}</p>
          </div>
          
          {/* 热门项目TVL卡片 */}
          <div className="data-card bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md border-l-4 border-[#4BCF93] hover:shadow-lg transition-shadow duration-300">
            <h3 className="text-lg font-semibold text-gray-600 dark:text-gray-400 mb-2">{t('hotProjectsTVL')}</h3>
            <p className="text-3xl font-bold text-gray-900 dark:text-white">{cryptoData.tvl}</p>
          </div>
        </div>
      </div>
    </section>
  );
}
