'use client';

import { useTranslations } from 'next-intl';
import { Link, useRouter } from '@/lib/i18n';

export default function LanguageSwitcher() {
  const t = useTranslations('common.language');
  const router = useRouter();
  
  // 切换语言处理函数
  const handleLanguageChange = (e) => {
    const newLocale = e.target.value;
    router.replace(router.asPath, { locale: newLocale });
  };
  
  return (
    <div className="language-switcher">
      <select onChange={handleLanguageChange} aria-label={t('select')}>
        <option value="zh-CN">{t('zh-CN')}</option>
        <option value="en">{t('en')}</option>
      </select>
    </div>
  );
}
