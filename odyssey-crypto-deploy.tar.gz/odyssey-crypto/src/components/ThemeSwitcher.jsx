// src/components/ThemeSwitcher.jsx
'use client';

import { useState, useEffect } from 'react';
import { useTranslations } from 'next-intl';

export default function ThemeSwitcher() {
  const t = useTranslations('common.darkMode');
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    // 检查用户之前的偏好设置
    const savedTheme = localStorage.getItem('theme');
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    
    if (savedTheme === 'dark' || (!savedTheme && prefersDark)) {
      setDarkMode(true);
      document.documentElement.classList.add('dark');
    }
  }, []);

  const toggleDarkMode = () => {
    if (darkMode) {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    } else {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    }
    setDarkMode(!darkMode);
  };

  return (
    <button 
      onClick={toggleDarkMode}
      className="theme-switcher"
      aria-label={t('toggle')}
    >
      {darkMode ? '☀️' : '🌙'}
    </button>
  );
}
