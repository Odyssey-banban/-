// src/components/ProfileSection.jsx
'use client';

import { useTranslations } from 'next-intl';

export default function ProfileSection() {
  const t = useTranslations('about.dimensions');
  
  return (
    <section className="profile-section py-16">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* 专业面 */}
          <div className="dimension-card bg-white dark:bg-gray-800 rounded-lg p-6 shadow-md">
            <h3 className="text-xl font-bold mb-4 text-[#2A5C8A] dark:text-[#4BCF93]">{t('professional')}</h3>
            
            <div className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">从业履历</h4>
                <p className="text-gray-700 dark:text-gray-300">
                  2018年进入加密行业，曾任职于头部交易所研究部门，负责市场分析和项目评估。2021年创立独立研究工作室，专注DeFi和Layer 2生态研究。
                </p>
              </div>
              
              <div>
                <h4 className="font-semibold mb-2">细分领域权威成绩</h4>
                <p className="text-gray-700 dark:text-gray-300">
                  首个预测LUNA崩盘时间误差&lt;3天，DeFi清算模型预测准确率达92%，多次受邀参与行业峰会发言。
                </p>
              </div>
            </div>
          </div>
          
          {/* 人性面 */}
          <div className="dimension-card bg-white dark:bg-gray-800 rounded-lg p-6 shadow-md">
            <h3 className="text-xl font-bold mb-4 text-[#2A5C8A] dark:text-[#4BCF93]">{t('personal')}</h3>
            
            <div>
              <h4 className="font-semibold mb-2">失败案例复盘</h4>
              <p className="text-gray-700 dark:text-gray-300">
                我在FTX暴雷中损失的300万教会我，即使是行业内部人士也可能被精心设计的骗局欺骗。这次经历让我更加重视风险管理和透明度，也促使我开始研究更安全的自托管解决方案。
              </p>
              <p className="text-gray-700 dark:text-gray-300 mt-4">
                每一次失败都是宝贵的学习机会，我愿意分享这些教训，帮助他人避免类似的陷阱。
              </p>
            </div>
          </div>
          
          {/* 价值观 */}
          <div className="dimension-card bg-white dark:bg-gray-800 rounded-lg p-6 shadow-md">
            <h3 className="text-xl font-bold mb-4 text-[#2A5C8A] dark:text-[#4BCF93]">{t('values')}</h3>
            
            <div>
              <h4 className="font-semibold mb-2">内容创作原则</h4>
              <ul className="list-disc list-inside space-y-2 text-gray-700 dark:text-gray-300">
                <li>不接软广、不做喊单</li>
                <li>观点独立，不受项目方影响</li>
                <li>数据驱动，避免情绪化判断</li>
                <li>承认不确定性，不做绝对预测</li>
                <li>公开方法论，接受公众监督</li>
                <li>尊重用户隐私，不收集敏感数据</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
