// src/components/ProjectCard.jsx
'use client';

import { useTranslations } from 'next-intl';
import { useState } from 'react';
import { Link } from '@/lib/i18n';

export default function ProjectCard({ project }) {
  const [expanded, setExpanded] = useState(false);
  
  // 使用默认项目数据，实际应从props接收
  const defaultProject = {
    id: 1,
    title: '2023 DeFi清算模型预测',
    slug: 'defi-liquidation-model-2023',
    category: 'research',
    thumbnail: '/images/defi-liquidation.jpg',
    valueProposition: '2023 DeFi清算模型预测误差率<8%',
    background: '随着DeFi市场的波动性增加，准确预测清算事件变得尤为重要。本项目旨在构建一个高精度的清算预测模型。',
    methodology: '结合链上数据分析、机器学习算法和宏观经济指标，构建了一个多维度的清算风险预测模型。',
    results: '模型在测试期间成功预测了超过92%的大额清算事件，平均提前12小时发出预警。'
  };
  
  const project = project || defaultProject;
  
  return (
    <div className="project-card bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-all duration-300">
      <div className="aspect-video bg-gray-200 dark:bg-gray-700 relative">
        {/* 实际项目中应该使用真实图片 */}
        <div className="absolute inset-0 flex items-center justify-center text-gray-500 dark:text-gray-400">
          [图片占位符: {project.title}]
        </div>
      </div>
      
      <div className="p-6">
        <div className="flex items-center mb-3">
          <span className="text-xs font-semibold px-2 py-1 bg-[#2A5C8A]/10 text-[#2A5C8A] dark:text-[#4BCF93] rounded">
            {project.category}
          </span>
        </div>
        
        <h3 className="text-xl font-bold mb-2">{project.title}</h3>
        <p className="text-lg font-semibold text-[#4BCF93] mb-4">{project.valueProposition}</p>
        
        {!expanded ? (
          <button 
            onClick={() => setExpanded(true)}
            className="text-[#2A5C8A] hover:text-[#4BCF93] font-medium transition-colors duration-300"
          >
            展开详情 ↓
          </button>
        ) : (
          <div className="project-details space-y-4 mt-4">
            <div>
              <h4 className="text-lg font-semibold mb-2">项目背景</h4>
              <p className="text-gray-600 dark:text-gray-300">{project.background}</p>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-2">方法论</h4>
              <p className="text-gray-600 dark:text-gray-300">{project.methodology}</p>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-2">成果数据</h4>
              <p className="text-gray-600 dark:text-gray-300">{project.results}</p>
            </div>
            
            <div className="flex justify-between items-center mt-6">
              <button 
                onClick={() => setExpanded(false)}
                className="text-[#2A5C8A] hover:text-[#4BCF93] font-medium transition-colors duration-300"
              >
                收起 ↑
              </button>
              
              <Link 
                href={`/portfolio/${project.slug}`}
                className="inline-block bg-[#2A5C8A] hover:bg-[#4BCF93] text-white font-semibold py-2 px-4 rounded transition-colors duration-300"
              >
                查看完整项目
              </Link>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
