// src/app/[locale]/analysis/[slug]/page.jsx
import { useTranslations } from 'next-intl';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import analysisData from '@/data/analysis.json';
import { notFound } from 'next/navigation';

export default function AnalysisDetailPage({ params }) {
  const { slug } = params;
  
  // 查找对应的分析文章
  const analysis = analysisData.find(item => item.slug === slug);
  
  // 如果找不到对应的文章，返回404
  if (!analysis) {
    notFound();
  }
  
  return (
    <main>
      <Header />
      
      <article className="py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <div className="mb-6">
              <div className="flex items-center mb-3">
                {analysis.tags.map((tag) => (
                  <span key={tag} className="text-xs font-semibold px-2 py-1 bg-[#2A5C8A]/10 text-[#2A5C8A] dark:text-[#4BCF93] rounded mr-2">
                    #{tag}
                  </span>
                ))}
                <span className="text-xs text-gray-500 dark:text-gray-400 ml-auto">
                  {analysis.date}
                </span>
              </div>
              
              <h1 className="text-3xl md:text-4xl font-bold mb-6">{analysis.title}</h1>
            </div>
            
            <div className="prose prose-lg dark:prose-invert max-w-none mb-8">
              {analysis.content.split('\n\n').map((paragraph, index) => (
                <p key={index}>{paragraph}</p>
              ))}
            </div>
            
            <div className="bg-gray-100 dark:bg-gray-800 p-6 rounded-lg mb-8">
              <h2 className="text-xl font-bold mb-4">分析框架</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h3 className="font-semibold text-[#2A5C8A] dark:text-[#4BCF93] mb-2">事件</h3>
                  <p>{analysis.event}</p>
                </div>
                
                <div>
                  <h3 className="font-semibold text-[#2A5C8A] dark:text-[#4BCF93] mb-2">数据图表</h3>
                  <p>{analysis.data}</p>
                </div>
                
                <div>
                  <h3 className="font-semibold text-[#2A5C8A] dark:text-[#4BCF93] mb-2">影响推演</h3>
                  <p>{analysis.impact}</p>
                </div>
                
                <div>
                  <h3 className="font-semibold text-[#2A5C8A] dark:text-[#4BCF93] mb-2">行动指南</h3>
                  <p>{analysis.action}</p>
                </div>
              </div>
            </div>
            
            <div className="flex justify-between items-center">
              <a 
                href="/analysis"
                className="inline-block bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300 font-semibold py-2 px-4 rounded transition-colors duration-300"
              >
                返回列表
              </a>
              
              <div className="flex space-x-4">
                <button className="text-[#2A5C8A] dark:text-[#4BCF93] hover:underline">
                  分享
                </button>
                <button className="text-[#2A5C8A] dark:text-[#4BCF93] hover:underline">
                  收藏
                </button>
              </div>
            </div>
          </div>
        </div>
      </article>
      
      <Footer />
    </main>
  );
}
