// src/app/[locale]/analysis/page.jsx
import { useTranslations } from 'next-intl';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import AnalysisCard from '@/components/AnalysisCard';
import AnalysisTagFilter from '@/components/AnalysisTagFilter';
import OpinionPoll from '@/components/OpinionPoll';
import analysisData from '@/data/analysis.json';

export default function AnalysisPage() {
  return (
    <main>
      <Header />
      
      <section className="py-12 bg-gray-50 dark:bg-gray-900">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl md:text-4xl font-bold mb-8">热点分析</h1>
          
          <AnalysisTagFilter />
          
          <div className="grid grid-cols-1 gap-8 mb-12">
            {analysisData.map((analysis) => (
              <AnalysisCard key={analysis.id} analysis={analysis} />
            ))}
          </div>
          
          <div className="mt-12">
            <OpinionPoll />
          </div>
        </div>
      </section>
      
      <Footer />
    </main>
  );
}
