// src/app/[locale]/page.jsx
import { useTranslations } from 'next-intl';
import HeroSection from '@/components/HeroSection';
import QuickNavCards from '@/components/QuickNavCards';
import DataDashboard from '@/components/DataDashboard';
import FeaturedContent from '@/components/FeaturedContent';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function HomePage() {
  return (
    <main>
      <Header />
      <HeroSection />
      <QuickNavCards />
      <DataDashboard />
      <FeaturedContent />
      <Footer />
    </main>
  );
}
