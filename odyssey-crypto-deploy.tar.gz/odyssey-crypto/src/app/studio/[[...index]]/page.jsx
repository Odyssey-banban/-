// src/app/studio/[[...index]]/page.jsx
'use client'

import { NextStudio } from 'next-sanity/studio'
import config from '../sanity.config'

export default function StudioPage() {
  return <NextStudio config={config} />
}
